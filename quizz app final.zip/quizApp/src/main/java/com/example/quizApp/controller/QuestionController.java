package com.example.quizApp.controller;


import com.example.quizApp.Questions;
import com.example.quizApp.dao.QuestionDao;
import com.example.quizApp.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("question")
public class QuestionController {

    @Autowired
    QuestionService questionService;
    @Autowired
    private QuestionDao questionDao;


    @GetMapping("allQuestions")
    public List<Questions> getAllQuestions()
    {
        return questionService.getAllQuestions();
    }

    @GetMapping("category/{category}")
    public List<Questions> getCategoryQuestions(@PathVariable("category") String category){
        return questionService.getQuestionsByCategory(category);
    }

    @PostMapping("add")
    public String addQuestion(@RequestBody Questions question){
        return questionService.addQuestion(question);
    }

    @DeleteMapping("delete")
    public String deleteQuestion(@RequestBody Questions question){
        return questionService.deleteQuestion(question);
    }

    @PutMapping("update")
    public String updateQuestion(@RequestBody Questions question){
        return questionService.updateQuestion(question);
    }


}
